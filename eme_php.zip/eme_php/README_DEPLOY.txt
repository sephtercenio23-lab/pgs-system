DEPLOY TO INFINITYFREE
1. In the InfinityFree control panel open File Manager (or use FTP) and go to /htdocs.
2. Upload everything inside this folder into /htdocs (index.php, curriculum.php, .htaccess,
   static/, templates/, data/). Make sure the hidden .htaccess files are uploaded too.
3. Open your site URL. Log in with:  admin / admin123   (or)   iPraise / admin123
4. Go to Users, create new accounts with real passwords, and delete the old ones.

Notes
- Student data lives in data/*.json (blocked from direct download by data/.htaccess).
- If you see a blank page or 500 error, set DEBUG to true near the top of index.php,
  reload to see the error, then set it back to false.
- Needs PHP 7.4 or newer (pick it in InfinityFree: Control Panel > PHP Config).
